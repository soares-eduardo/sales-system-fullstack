class ItemCarrinho {
  constructor(produto, qtdade) {
    this.produto = produto;
    this.qtdade = qtdade;
  }
}
