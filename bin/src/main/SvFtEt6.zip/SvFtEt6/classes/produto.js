class Produto {
  constructor(codigo, descricao, preco, quantidade) {
    this.descricao = descricao;
    this.codigo = codigo;
    this.preco = preco;
    this.quantidade = quantidade;
  }
}
